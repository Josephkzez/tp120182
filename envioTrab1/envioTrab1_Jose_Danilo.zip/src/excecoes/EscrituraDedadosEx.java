package excecoes;

@SuppressWarnings("serial")
public class EscrituraDedadosEx extends AcessoDadosEx {
	public EscrituraDedadosEx(String mensagem){
		super(mensagem);
	
	}
}
