package excecoes;

@SuppressWarnings("serial")
public class LeituraDadosEx extends AcessoDadosEx {
	
    public LeituraDadosEx(String mensagem) {
    	super(mensagem);
}        
    }
    
